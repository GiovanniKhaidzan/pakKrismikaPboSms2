/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package latihan1;

/**
 *
 * @author GIOVANI DAVINCI
 */
public class CetakVolume {
    public static void cetak(BangunDatar obj){
        obj.tampilVolume();
        System.out.println("VOLUME "+obj.getNama()+ "    = " +obj.hitungVolume());
    }
}
