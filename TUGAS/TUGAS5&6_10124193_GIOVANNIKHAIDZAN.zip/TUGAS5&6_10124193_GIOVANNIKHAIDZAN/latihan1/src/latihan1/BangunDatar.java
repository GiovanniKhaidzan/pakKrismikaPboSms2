/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package latihan1;

/**
 *
 * @author GIOVANI DAVINCI
 */
public class BangunDatar {
    private String nama;
    protected double phi = 3.14;
    
    public String getNama() {
        return nama;
    }
   
    public void setNama(String nama) {
        this.nama = nama;
    }
    

    public void tampilStatus(){
        System.out.println("TAMPIL VOLUME "+this.getNama());
    }
    

    public double hitungVolume(){
        return 0;
    }
    
    public void tampilVolume(){
        System.out.println("");
    }

  
    
}
